# A simple setup script to create an executable using PyQt4. This also
# demonstrates the method for creating a Windows executable that does not have
# an associated console.
#
# PyQt4app.py is a very simple type of PyQt4 application
#
# Run the build process by running the command 'python setup.py build'
#
# If everything works well you should find a subdirectory in the build
# subdirectory that contains the files needed to run the application

import sys

from cx_Freeze import setup, Executable

base = None
includes = ['re', 'PyQt4', 'os', 'sys', 'atexit']
if sys.platform == "win32":
    base = "Win32GUI"

setup(
        name = "TextEdit",
        version = "0.1",
        description = "TextEdit",
        options = {"build_exe" : {"includes" : includes}},
        executables = [Executable("textedit.py", base = base, icon=r"images\logo.ico")])

